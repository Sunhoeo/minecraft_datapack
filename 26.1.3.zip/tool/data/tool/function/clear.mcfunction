kill @e[type=!player,tag=!InMap]
kill @e[type=!player,tag=!InMap]