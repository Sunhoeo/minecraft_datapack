time set day
gamerule advance_time false